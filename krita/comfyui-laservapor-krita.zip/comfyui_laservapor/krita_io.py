"""Canvas <-> bytes helpers. MUST be called on Krita's main (GUI) thread."""
from krita import Krita
from PyQt5.QtCore import QBuffer, QByteArray, QIODevice, Qt
from PyQt5.QtGui import QImage, QPixmap


def export_canvas_png(doc):
    """Return PNG bytes of the merged visible image, or None if no document."""
    if doc is None:
        return None
    w, h = doc.width(), doc.height()
    img = doc.projection(0, 0, w, h)          # QImage of the flattened canvas
    if img is None or img.isNull():
        return None
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.WriteOnly)
    img.save(buf, "PNG")
    buf.close()
    return bytes(ba)


def insert_image_as_layer(doc, img_bytes, name="LaserVapor Result"):
    """Load an image and add it as a new paint layer at the top. Main thread."""
    if doc is None:
        raise RuntimeError("没有打开的文档，无法导入结果")

    qimg = QImage()
    if not qimg.loadFromData(QByteArray(img_bytes)):
        raise RuntimeError("结果图片解码失败")

    # Krita 8-bit RGBA stores channels as BGRA, which is exactly QImage
    # Format_ARGB32's little-endian memory layout (B,G,R,A).
    qimg = qimg.convertToFormat(QImage.Format_ARGB32)
    w, h = qimg.width(), qimg.height()

    ptr = qimg.constBits()
    ptr.setsize(qimg.sizeInBytes() if hasattr(qimg, "sizeInBytes") else qimg.byteCount())
    pixel_bytes = bytes(ptr)

    layer = doc.createNode(name, "paintlayer")
    doc.rootNode().addChildNode(layer, None)
    layer.setPixelData(QByteArray(pixel_bytes), 0, 0, w, h)
    doc.refreshProjection()
    return layer


def open_image_in_new_doc(img_bytes, name="LaserVapor"):
    """Open image bytes as a brand-new Krita document with one paint layer."""
    qimg = QImage()
    if not qimg.loadFromData(QByteArray(img_bytes)):
        raise RuntimeError("结果图片解码失败")
    qimg = qimg.convertToFormat(QImage.Format_ARGB32)
    w, h = qimg.width(), qimg.height()

    app = Krita.instance()
    doc = app.createDocument(w, h, name, "RGBA", "U8", "", 300.0)

    ptr = qimg.constBits()
    ptr.setsize(qimg.sizeInBytes() if hasattr(qimg, "sizeInBytes") else qimg.byteCount())
    layer = doc.topLevelNodes()[0]
    layer.setPixelData(QByteArray(bytes(ptr)), 0, 0, w, h)
    doc.refreshProjection()
    app.activeWindow().addView(doc)
    return doc


def pixmap_from_bytes(img_bytes, max_side=96):
    """Build a scaled QPixmap thumbnail from image bytes (for previews)."""
    qimg = QImage()
    if not qimg.loadFromData(QByteArray(img_bytes)):
        return None
    pm = QPixmap.fromImage(qimg)
    if pm.width() > max_side or pm.height() > max_side:
        pm = pm.scaled(max_side, max_side, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    return pm
