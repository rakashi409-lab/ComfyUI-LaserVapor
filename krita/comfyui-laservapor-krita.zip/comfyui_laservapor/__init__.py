"""ComfyUI-LaserVapor for Krita.

Native Krita (PyKrita) port of the LibLib ComfyUI plugin originally
distributed as an Adobe Photoshop UXP plugin. The LibLib cloud API protocol
(HMAC-SHA1 signing, generate request, status polling, result extraction) is a
faithful reimplementation of the original; the canvas I/O and UI are rebuilt
with Krita's Python API and PyQt5.
"""
from krita import Krita, DockWidgetFactory, DockWidgetFactoryBase
from .docker import LaserVaporDocker, DOCKER_ID

Krita.instance().addDockWidgetFactory(
    DockWidgetFactory(DOCKER_ID, DockWidgetFactoryBase.DockRight, LaserVaporDocker)
)
