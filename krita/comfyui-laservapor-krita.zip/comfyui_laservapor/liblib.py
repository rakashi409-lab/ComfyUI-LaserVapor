"""LibLib ComfyUI cloud API client (stdlib only — Krita's bundled Python).

Faithful port of the original UXP plugin's networking layer:
  - signUrl  : HMAC-SHA1 request signing (LibLib openapi spec)
  - upload   : catbox litterbox (primary) -> tmpfiles.org (fallback)
  - generate : POST /api/generate/comfyui/app  {templateUuid, generateParams}
  - poll     : POST /api/generate/comfy/status {generateUuid}
  - extract  : pull result image URLs out of the status payload
"""
import json
import time
import hmac
import hashlib
import base64
import random
import uuid
import urllib.request
import urllib.parse
import ssl


# --- signing ---------------------------------------------------------------

def _nonce():
    return "".join(random.choice("0123456789abcdef") for _ in range(32))


def sign_uri(uri, access_key, secret_key):
    """Return `uri` with AccessKey/Signature/Timestamp/SignatureNonce appended.

    `uri` is the path (+ optional query) portion only, e.g. /api/generate/...
    Matches the original signUrl(): base64(HMAC-SHA1(sk, uri&ts&nonce)),
    url-safe, '=' stripped.
    """
    ts = str(int(time.time() * 1000))
    nc = _nonce()
    content = uri + "&" + ts + "&" + nc
    digest = hmac.new(secret_key.encode("utf-8"), content.encode("utf-8"),
                      hashlib.sha1).digest()
    sig = base64.b64encode(digest).decode("ascii")
    sig = sig.replace("+", "-").replace("/", "_").rstrip("=")
    q = urllib.parse.urlencode({
        "AccessKey": access_key,
        "Signature": sig,
        "Timestamp": ts,
        "SignatureNonce": nc,
    })
    sep = "&" if "?" in uri else "?"
    return uri + sep + q


def _split(url):
    """Split absolute URL into (scheme://host, path+query)."""
    p = urllib.parse.urlsplit(url)
    host = "{}://{}".format(p.scheme, p.netloc)
    path = p.path or "/"
    if p.query:
        path += "?" + p.query
    return host, path


# --- low level http --------------------------------------------------------

class LibLibError(Exception):
    pass


def _opener(proxy):
    handlers = []
    if proxy:
        handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


def _post_json(url, payload, proxy=None, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    with _opener(proxy).open(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8", "replace")
    try:
        return json.loads(body)
    except ValueError:
        raise LibLibError("Non-JSON response: " + body[:300])


# --- multipart image upload ------------------------------------------------

def _multipart(fields, file_field, filename, file_bytes, content_type):
    boundary = "----LaserVapor" + uuid.uuid4().hex
    crlf = b"\r\n"
    out = []
    for k, v in fields.items():
        out.append(("--" + boundary).encode())
        out.append(('Content-Disposition: form-data; name="%s"' % k).encode())
        out.append(b"")
        out.append(str(v).encode())
    out.append(("--" + boundary).encode())
    out.append(('Content-Disposition: form-data; name="%s"; filename="%s"'
                % (file_field, filename)).encode())
    out.append(("Content-Type: " + content_type).encode())
    out.append(b"")
    out.append(file_bytes)
    out.append(("--" + boundary + "--").encode())
    out.append(b"")
    body = crlf.join(out)
    return body, "multipart/form-data; boundary=" + boundary


def upload_image(img_bytes, proxy=None, log=lambda *a: None):
    """Upload bytes to a temp host, return a public URL. catbox -> tmpfiles."""
    fname = "krita_%d.png" % int(time.time())

    # (1) litterbox.catbox.moe — returns the raw URL as text.
    try:
        body, ctype = _multipart(
            {"reqtype": "fileupload", "time": "1h"},
            "fileToUpload", fname, img_bytes, "image/png")
        req = urllib.request.Request(
            "https://litterbox.catbox.moe/resources/internals/api.php",
            data=body, method="POST")
        req.add_header("Content-Type", ctype)
        with _opener(proxy).open(req, timeout=120) as resp:
            url = resp.read().decode("utf-8", "replace").strip()
        if url.startswith("http"):
            log("图片上传成功 (catbox)", "ok")
            return url
        log("通道①返回异常: " + url[:80] + ", 尝试通道②...", "warn")
    except Exception as e:
        log("通道①错误: %s, 尝试通道②..." % e, "warn")

    # (2) tmpfiles.org — JSON {data:{url: ".../<id>/<name>"}}; needs /dl/ form.
    try:
        body, ctype = _multipart(
            {}, "file", fname, img_bytes, "image/png")
        req = urllib.request.Request(
            "https://tmpfiles.org/api/v1/upload", data=body, method="POST")
        req.add_header("Content-Type", ctype)
        with _opener(proxy).open(req, timeout=120) as resp:
            j = json.loads(resp.read().decode("utf-8", "replace"))
        page = j.get("data", {}).get("url", "")
        if page:
            direct = page.replace("tmpfiles.org/", "tmpfiles.org/dl/", 1)
            log("图片上传成功 (tmpfiles)", "ok")
            return direct
    except Exception as e:
        log("通道②错误: %s" % e, "warn")

    raise LibLibError("图片上传失败（两个通道都不可用，可能需要配置代理）")


# --- generate / poll -------------------------------------------------------

def generate(api_url, template_uuid, generate_params, ak, sk, proxy=None):
    host, path = _split(api_url)
    full = host + sign_uri(path, ak, sk)
    body = {"templateUuid": template_uuid, "generateParams": generate_params}
    data = _post_json(full, body, proxy)
    code = data.get("code")
    if code not in (None, 0):
        raise LibLibError(str(data.get("msg") or data.get("message")) + " code=" + str(code))
    d = data.get("data") or {}
    tid = d.get("generateUuid") or d.get("taskId") or d.get("id") \
        or data.get("generateUuid") or data.get("taskId")
    if not tid:
        raise LibLibError("未拿到 generateUuid: " + json.dumps(data)[:300])
    return tid


def poll_once(status_url, generate_uuid, ak, sk, proxy=None):
    host, path = _split(status_url)
    full = host + sign_uri(path, ak, sk)
    data = _post_json(full, {"generateUuid": generate_uuid}, proxy)
    td = data.get("data") or data
    st = td.get("generateStatus", td.get("status"))
    raw = td.get("percentCompleted") or td.get("progress") or 0
    pct = round(raw * 100) if raw and raw <= 1 else round(raw or 0)
    return st, pct, td


def is_finished(st):
    return st in (5, "FINISH", "completed")


def is_failed(st):
    return st in (6, "FAILED", "failed", "error")


_IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")


def extract_urls(td):
    """Recursively collect image URLs from a status payload."""
    found = []

    def walk(x):
        if isinstance(x, str):
            low = x.lower()
            if low.startswith("http") and any(e in low for e in _IMG_EXT):
                found.append(x)
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)

    walk(td)
    # de-dup, preserve order
    seen, out = set(), []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def download(url, proxy=None, timeout=120):
    req = urllib.request.Request(url, method="GET")
    with _opener(proxy).open(req, timeout=timeout) as resp:
        return resp.read()
