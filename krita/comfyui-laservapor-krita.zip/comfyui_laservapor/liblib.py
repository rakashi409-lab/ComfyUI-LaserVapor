"""LibLib ComfyUI cloud API client (stdlib only — Krita's bundled Python).

Faithful port of the original UXP plugin's networking layer:
  - signUrl  : HMAC-SHA1 request signing (LibLib openapi spec)
  - upload   : catbox litterbox (primary) -> tmpfiles.org (fallback)
  - generate : POST /api/generate/comfyui/app  {templateUuid, generateParams}
  - poll     : POST /api/generate/comfy/status {generateUuid}
  - extract  : pull result image URLs out of the status payload
"""
import json
import time
import hmac
import hashlib
import base64
import random
import uuid
import struct
import zlib
import urllib.request
import urllib.parse
import urllib.error
import ssl


def solid_png(width=1024, height=1024, rgb=(255, 255, 255)):
    """生成一张纯色 PNG 的 bytes(stdlib only)。用于文生图占位的 LoadImage 输入。"""
    width = max(1, min(int(width or 1024), 4096))
    height = max(1, min(int(height or 1024), 4096))
    r, g, b = rgb
    # 每行: 1 字节 filter(0) + width*3 字节像素
    row = bytes([0]) + bytes([r, g, b]) * width
    raw = row * height
    comp = zlib.compress(raw, 9)

    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)

    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # 8bit RGB
    return sig + chunk(b"IHDR", ihdr) + chunk(b"IDAT", comp) + chunk(b"IEND", b"")


# --- signing ---------------------------------------------------------------

def _nonce():
    return "".join(random.choice("0123456789abcdef") for _ in range(32))


def sign_uri(uri, access_key, secret_key):
    """Return `uri` with AccessKey/Signature/Timestamp/SignatureNonce appended.

    `uri` is the path (+ optional query) portion only, e.g. /api/generate/...
    Matches the original signUrl(): base64(HMAC-SHA1(sk, uri&ts&nonce)),
    url-safe, '=' stripped.
    """
    ts = str(int(time.time() * 1000))
    nc = _nonce()
    content = uri + "&" + ts + "&" + nc
    digest = hmac.new(secret_key.encode("utf-8"), content.encode("utf-8"),
                      hashlib.sha1).digest()
    sig = base64.b64encode(digest).decode("ascii")
    sig = sig.replace("+", "-").replace("/", "_").rstrip("=")
    q = urllib.parse.urlencode({
        "AccessKey": access_key,
        "Signature": sig,
        "Timestamp": ts,
        "SignatureNonce": nc,
    })
    sep = "&" if "?" in uri else "?"
    return uri + sep + q


def _split(url):
    """Split absolute URL into (scheme://host, path+query)."""
    p = urllib.parse.urlsplit(url)
    host = "{}://{}".format(p.scheme, p.netloc)
    path = p.path or "/"
    if p.query:
        path += "?" + p.query
    return host, path


# --- low level http --------------------------------------------------------

class LibLibError(Exception):
    pass


def _opener(proxy):
    handlers = []
    if proxy:
        handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


def _post_json(url, payload, proxy=None, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    with _opener(proxy).open(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8", "replace")
    try:
        return json.loads(body)
    except ValueError:
        raise LibLibError("Non-JSON response: " + body[:300])


# --- multipart image upload ------------------------------------------------

def _multipart(fields, file_field, filename, file_bytes, content_type):
    boundary = "----LaserVapor" + uuid.uuid4().hex
    crlf = b"\r\n"
    out = []
    for k, v in fields.items():
        out.append(("--" + boundary).encode())
        out.append(('Content-Disposition: form-data; name="%s"' % k).encode())
        out.append(b"")
        out.append(str(v).encode())
    out.append(("--" + boundary).encode())
    out.append(('Content-Disposition: form-data; name="%s"; filename="%s"'
                % (file_field, filename)).encode())
    out.append(("Content-Type: " + content_type).encode())
    out.append(b"")
    out.append(file_bytes)
    out.append(("--" + boundary + "--").encode())
    out.append(b"")
    body = crlf.join(out)
    return body, "multipart/form-data; boundary=" + boundary


def _liblib_oss_upload(img_bytes, ak, sk, proxy=None, log=lambda *a: None,
                       sig_host="https://openapi.liblibai.cloud"):
    """官方推荐: 通过 LibLib 预签名上传到其 OSS, 返回 liblib 自有域名的图片 URL。
    外部匿名图床(uguu 等)会被 LibLib 内容审核判为违规, 故首选官方通道。

    流程(与官方 SDK 一致):
      1. POST /api/generate/upload/signature  body {name, extension}  (HMAC 签名)
         -> data: {postUrl, key, xossSignature, xossDate, policy,
                   xossCredential, xossSignatureVersion, xossExpires}
      2. multipart POST 到 postUrl(OSS), 带上这些字段 + file
      3. 最终图片 URL = postUrl 去掉末尾'/' + '/' + key
    """
    name = "krita_%d" % int(time.time())
    ext = "png"
    path = sign_uri("/api/generate/upload/signature", ak, sk)
    sig = _post_json(sig_host + path, {"name": name, "extension": ext}, proxy)
    if sig.get("code") not in (None, 0):
        raise LibLibError("获取上传签名失败: " + str(sig.get("msg") or sig))
    d = sig.get("data") or {}
    post_url = d.get("postUrl") or d.get("post_url") or d.get("host") or d.get("uploadUrl")
    key = d.get("key") or d.get("objectKey") or d.get("fileKey")
    if not post_url or not key:
        raise LibLibError("上传签名返回缺少 postUrl/key, 实际字段: "
                          + ",".join(sorted(d.keys()))[:300])

    # 容错取值: API 字段名可能是驼峰/连字符/下划线等多种写法
    def pick(*names):
        for n in names:
            if n in d and d[n] not in (None, ""):
                return d[n]
        return ""

    sig_ver = pick("xOssSignatureVersion", "xossSignatureVersion",
                   "x-oss-signature-version") or "OSS4-HMAC-SHA256"
    fields = {
        "key": key,
        "policy": pick("policy", "Policy"),
        "x-oss-signature-version": sig_ver,
        "x-oss-credential": pick("xOssCredential", "xossCredential",
                                 "x-oss-credential", "credential"),
        "x-oss-date": pick("xOssDate", "xossDate", "x-oss-date", "date"),
        "x-oss-expires": str(pick("xOssExpires", "xossExpires",
                                  "x-oss-expires", "expires")),
        "x-oss-signature": pick("xOssSignature", "xossSignature",
                                "x-oss-signature", "signature", "Signature"),
    }
    # 把缺失的关键字段暴露出来, 便于排查
    missing = [k for k in ("policy", "x-oss-credential", "x-oss-date", "x-oss-signature")
               if not fields[k]]
    if missing:
        raise LibLibError("签名字段缺失 " + ",".join(missing)
                          + "; 返回字段: " + ",".join(sorted(d.keys()))[:300])
    body, ctype = _multipart(fields, "file", name + "." + ext, img_bytes, "image/png")
    req = urllib.request.Request(post_url, data=body, method="POST")
    req.add_header("Content-Type", ctype)
    try:
        with _opener(proxy).open(req, timeout=120) as resp:
            resp.read()   # OSS 成功返回 204/200, 无 body
    except urllib.error.HTTPError as he:
        detail = ""
        try:
            xml = he.read().decode("utf-8", "replace")
            import re as _re
            def _grab(tag):
                m = _re.search("<%s>(.*?)</%s>" % (tag, tag), xml, _re.S)
                return m.group(1).strip() if m else ""
            code = _grab("Code")
            msg = _grab("Message")
            an = _grab("ArgumentName")
            av = _grab("ArgumentValue")
            detail = code + ": " + msg
            if an:
                detail += " | 字段=" + an + " 值=" + av[:60]
            if not detail.strip(": "):
                detail = xml[:500]
        except Exception:
            detail = "(无法解析错误响应)"
        raise LibLibError("OSS 上传被拒 HTTP %s: %s" % (he.code, detail))

    # 最终图片 URL: postUrl 的 host + key (key 是相对路径)
    parts = urllib.parse.urlsplit(post_url)
    url = "{}://{}/{}".format(parts.scheme, parts.netloc, key.lstrip("/"))
    log("图片上传成功 (LibLib)", "ok")
    return url


def _try_host(host, img_bytes, fname, proxy, timeout=25):
    """按单个图床配置上传, 成功返回直链 URL, 失败抛异常。
    超时 25s: 正常上传几秒内完成; 挂掉的图床快速跳过, 不傻等。"""
    body, ctype = _multipart(host["fields"], host["file_field"], fname,
                             img_bytes, "image/png")
    req = urllib.request.Request(host["url"], data=body, method="POST")
    req.add_header("Content-Type", ctype)
    req.add_header("User-Agent", "Mozilla/5.0")
    with _opener(proxy).open(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8", "replace")
    return host["parse"](raw)


# 免费图床备用链(无需 API key)。从前往后依次尝试, 任一成功即返回。
# parse: 从响应文本里取出图片直链 URL。
_HOSTS = [
    {   # tmpfiles.org — 你原 PS 插件用过的同类, LibLib 最可能接受
        "name": "tmpfiles",
        "url": "https://tmpfiles.org/api/v1/upload",
        "file_field": "file", "fields": {},
        "parse": lambda r: json.loads(r).get("data", {}).get("url", "")
                 .replace("tmpfiles.org/", "tmpfiles.org/dl/", 1),
    },
    {   # uguu.se
        "name": "uguu",
        "url": "https://uguu.se/upload.php",
        "file_field": "files[]", "fields": {},
        "parse": lambda r: (json.loads(r).get("files") or [{}])[0].get("url", ""),
    },
    {   # qu.ax
        "name": "qu.ax",
        "url": "https://qu.ax/upload.php",
        "file_field": "files[]", "fields": {},
        "parse": lambda r: (json.loads(r).get("files") or [{}])[0].get("url", ""),
    },
    {   # kappa.lol
        "name": "kappa",
        "url": "https://kappa.lol/api/upload",
        "file_field": "file", "fields": {},
        "parse": lambda r: json.loads(r).get("link", ""),
    },
    {   # catbox(永久, 偶尔可用)
        "name": "catbox",
        "url": "https://catbox.moe/user/api.php",
        "file_field": "fileToUpload",
        "fields": {"reqtype": "fileupload"},
        "parse": lambda r: r.strip() if r.strip().startswith("http") else "",
    },
]


def upload_image(img_bytes, proxy=None, log=lambda *a: None, ak=None, sk=None):
    """上传图片, 返回公网直链。

    首选 LibLib 官方 OSS(URL 在 liblib 自有域名, 不会被内容审核拦截);
    官方失败再退回免费图床(海外匿名图床多被 LibLib 判违规, 仅作兜底)。
    """
    if ak and sk:
        try:
            return _liblib_oss_upload(img_bytes, ak, sk, proxy=proxy, log=log)
        except Exception as e:
            log("LibLib 官方上传失败: %s, 尝试备用图床..." % e, "warn")

    fname = "krita_%d.png" % int(time.time())
    for h in _HOSTS:
        try:
            url = _try_host(h, img_bytes, fname, proxy)
            if url and url.startswith("http"):
                log("图片上传成功 (%s)" % h["name"], "ok")
                return url
            log("通道 %s 返回异常, 换下一个..." % h["name"], "warn")
        except Exception as e:
            log("通道 %s 失败: %s, 换下一个..." % (h["name"], e), "warn")
    raise LibLibError("图片上传失败（所有图床都不可用，可在「配置」填代理后重试）")


# --- generate / poll -------------------------------------------------------

def generate(api_url, template_uuid, generate_params, ak, sk, proxy=None):
    host, path = _split(api_url)
    full = host + sign_uri(path, ak, sk)
    body = {"templateUuid": template_uuid, "generateParams": generate_params}
    data = _post_json(full, body, proxy)
    code = data.get("code")
    if code not in (None, 0):
        raise LibLibError(str(data.get("msg") or data.get("message")) + " code=" + str(code))
    d = data.get("data") or {}
    tid = d.get("generateUuid") or d.get("taskId") or d.get("id") \
        or data.get("generateUuid") or data.get("taskId")
    if not tid:
        raise LibLibError("未拿到 generateUuid: " + json.dumps(data)[:300])
    return tid


def poll_once(status_url, generate_uuid, ak, sk, proxy=None):
    host, path = _split(status_url)
    full = host + sign_uri(path, ak, sk)
    data = _post_json(full, {"generateUuid": generate_uuid}, proxy)
    td = data.get("data") or data
    st = td.get("generateStatus", td.get("status"))
    raw = td.get("percentCompleted") or td.get("progress") or 0
    pct = round(raw * 100) if raw and raw <= 1 else round(raw or 0)
    return st, pct, td


def is_finished(st):
    return st in (5, "FINISH", "completed")


def is_failed(st):
    return st in (6, "FAILED", "failed", "error")


_IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")


def extract_urls(td):
    """Recursively collect image URLs from a status payload."""
    found = []

    def walk(x):
        if isinstance(x, str):
            low = x.lower()
            if low.startswith("http") and any(e in low for e in _IMG_EXT):
                found.append(x)
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)

    walk(td)
    # de-dup, preserve order
    seen, out = set(), []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def download(url, proxy=None, timeout=120):
    req = urllib.request.Request(url, method="GET")
    with _opener(proxy).open(req, timeout=timeout) as resp:
        return resp.read()
