"""Krita docker UI + background worker for ComfyUI-LaserVapor.

Feature parity with the original Photoshop UXP plugin:
  - upload a local reference image (file picker) OR use the current canvas
  - positive prompt -> CR Text node
  - input/output dimensions -> width/height node overrides
  - collapsible sections
  - results shown as a thumbnail grid, each with import / open-in-new-doc
"""
import json
import time

from krita import Krita, DockWidget
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout, QLabel,
    QLineEdit, QPushButton, QComboBox, QPlainTextEdit, QProgressBar,
    QScrollArea, QSpinBox, QFileDialog, QToolButton, QFrame, QSizePolicy,
)

from . import liblib
from .krita_io import (
    export_canvas_png, insert_image_as_layer, open_image_in_new_doc,
    pixmap_from_bytes,
)

DOCKER_ID = "comfyui_laservapor"
SETTINGS_GROUP = "ComfyUI-LaserVapor"
MAX_POLLS = 120
POLL_INTERVAL = 2.0

DEFAULT_API = "https://openapi.liblibai.cloud/api/generate/comfyui/app"
DEFAULT_STATUS = "https://openapi.liblibai.cloud/api/generate/comfy/status"


# ---------------------------------------------------------------------------
# Collapsible section widget
# ---------------------------------------------------------------------------
class Collapsible(QWidget):
    """A header button that shows/hides a content area below it."""

    def __init__(self, title, collapsed=False):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.toggle = QToolButton()
        self.toggle.setText(title)
        self.toggle.setCheckable(True)
        self.toggle.setChecked(not collapsed)
        self.toggle.setStyleSheet(
            "QToolButton{border:none;font-weight:bold;text-align:left;padding:4px 2px;}")
        self.toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toggle.setArrowType(Qt.DownArrow if not collapsed else Qt.RightArrow)
        self.toggle.clicked.connect(self._on_toggle)

        self.content = QFrame()
        self.content.setFrameShape(QFrame.StyledPanel)
        self.body = QVBoxLayout(self.content)
        self.body.setContentsMargins(8, 6, 8, 8)
        self.body.setSpacing(6)
        self.content.setVisible(not collapsed)

        lay.addWidget(self.toggle)
        lay.addWidget(self.content)

    def _on_toggle(self, checked):
        self.content.setVisible(checked)
        self.toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)

    def add(self, w):
        self.body.addWidget(w)

    def add_layout(self, l):
        self.body.addLayout(l)


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------
class GenerateWorker(QThread):
    sig_log = pyqtSignal(str, str)
    sig_progress = pyqtSignal(str, int)
    sig_result = pyqtSignal(list)         # list of (bytes, url)
    sig_error = pyqtSignal(str)
    sig_done = pyqtSignal()

    def __init__(self, cfg, input_png):
        super().__init__()
        self.cfg = cfg
        self.input_png = input_png

    def run(self):
        cfg = self.cfg
        proxy = cfg.get("proxy") or None
        try:
            gp = {"workflowUuid": cfg["workflow_uuid"]}

            # positive prompt -> CR Text node (original used node 57)
            if cfg.get("prompt"):
                gp[cfg["prompt_node"]] = {
                    "class_type": cfg["prompt_class"],
                    "inputs": {"text": cfg["prompt"]},
                }

            # dimension overrides
            w, h = cfg.get("width"), cfg.get("height")
            if cfg.get("dim_node") and w and h:
                gp[cfg["dim_node"]] = {
                    "class_type": cfg["dim_class"],
                    "inputs": {"width": w, "height": h},
                }

            # extra raw JSON overrides
            extra = cfg.get("extra_json", "").strip()
            if extra:
                try:
                    gp.update(json.loads(extra))
                except ValueError as e:
                    raise liblib.LibLibError("附加参数 JSON 格式错误: %s" % e)

            # reference image (local upload or canvas)
            if self.input_png:
                self.sig_progress.emit("正在上传图片...", 3)
                url = liblib.upload_image(
                    self.input_png, proxy=proxy,
                    log=lambda m, lv="info": self.sig_log.emit(m, lv))
                gp[cfg["img_node"]] = {
                    "class_type": cfg["img_class"],
                    "inputs": {"image": url},
                }
                self.sig_log.emit("图片已设置到节点 " + cfg["img_node"], "info")

            self.sig_progress.emit("正在提交...", 5)
            self.sig_log.emit("工作流: " + cfg["workflow_uuid"][:12] + "...", "info")
            tid = liblib.generate(
                cfg["api_url"], cfg["template_uuid"], gp,
                cfg["ak"], cfg["sk"], proxy=proxy)
            self.sig_log.emit("任务已提交: " + str(tid)[:16] + "...", "ok")

            for n in range(MAX_POLLS):
                time.sleep(POLL_INTERVAL)
                st, pct, td = liblib.poll_once(
                    cfg["status_url"], tid, cfg["ak"], cfg["sk"], proxy=proxy)
                self.sig_progress.emit("处理中...", max(pct, 6))
                self.sig_log.emit("#%d 状态=%s %d%%" % (n + 1, st, pct), "info")

                if liblib.is_finished(st):
                    urls = liblib.extract_urls(td)
                    if not urls:
                        raise liblib.LibLibError("任务完成但未找到图片 URL")
                    self.sig_log.emit("完成，共 %d 张图片" % len(urls), "ok")
                    self.sig_progress.emit("下载结果...", 98)
                    out = []
                    for u in urls:
                        try:
                            out.append((liblib.download(u, proxy=proxy), u))
                        except Exception as e:
                            self.sig_log.emit("下载失败 %s: %s" % (u, e), "warn")
                    self.sig_result.emit(out)
                    self.sig_progress.emit("完成", 100)
                    return
                if liblib.is_failed(st):
                    fm = td.get("failedMessage") or td.get("errorMessage") \
                        or td.get("msg") or json.dumps(td)[:200]
                    raise liblib.LibLibError("任务失败: " + str(fm))

            raise liblib.LibLibError("轮询超时")
        except Exception as e:
            self.sig_error.emit(str(e))
        finally:
            self.sig_done.emit()


# ---------------------------------------------------------------------------
# Docker
# ---------------------------------------------------------------------------
class LaserVaporDocker(DockWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ComfyUI-LaserVapor")
        self.worker = None
        self.local_image = None       # bytes of a user-picked reference image
        self._build_ui()
        self._load_settings()

    # --- UI ----------------------------------------------------------------
    def _build_ui(self):
        root = QWidget()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(root)

        v = QVBoxLayout(root)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)

        # ----- 密钥 / 工作流 (collapsible, collapsed once filled) -----
        self.sec_cfg = Collapsible("① 密钥 / 工作流配置", collapsed=False)
        form = QFormLayout()
        form.setContentsMargins(0, 0, 0, 0)
        self.in_ak = QLineEdit()
        self.in_sk = QLineEdit(); self.in_sk.setEchoMode(QLineEdit.Password)
        self.in_template = QLineEdit()
        self.in_workflow = QLineEdit()
        self.in_api = QLineEdit(DEFAULT_API)
        self.in_status = QLineEdit(DEFAULT_STATUS)
        form.addRow("AccessKey", self.in_ak)
        form.addRow("SecretKey", self.in_sk)
        form.addRow("templateUuid", self.in_template)
        form.addRow("workflowUuid", self.in_workflow)
        form.addRow("API URL", self.in_api)
        form.addRow("Status URL", self.in_status)
        self.sec_cfg.add_layout(form)
        v.addWidget(self.sec_cfg)

        # ----- 图片输入 -----
        self.sec_img = Collapsible("② 图片输入（图生图，可选）", collapsed=False)
        self.in_mode = QComboBox()
        self.in_mode.addItem("不使用图片（文生图）", "none")
        self.in_mode.addItem("上传本地图片", "local")
        self.in_mode.addItem("使用当前画布", "canvas")
        self.in_mode.currentIndexChanged.connect(self._on_mode_change)
        self.sec_img.add(self.in_mode)

        upload_row = QHBoxLayout()
        self.btn_upload = QPushButton("选择参考图...")
        self.btn_upload.clicked.connect(self.on_pick_local)
        self.btn_clear_img = QPushButton("清除")
        self.btn_clear_img.clicked.connect(self.on_clear_local)
        upload_row.addWidget(self.btn_upload)
        upload_row.addWidget(self.btn_clear_img)
        self._upload_row_w = QWidget(); self._upload_row_w.setLayout(upload_row)
        self.sec_img.add(self._upload_row_w)

        self.lbl_thumb = QLabel("（未选择参考图）")
        self.lbl_thumb.setAlignment(Qt.AlignCenter)
        self.lbl_thumb.setMinimumHeight(70)
        self.lbl_thumb.setStyleSheet("color:#888;border:1px dashed #555;border-radius:4px;")
        self.sec_img.add(self.lbl_thumb)

        node_row = QFormLayout()
        self.in_node = QLineEdit("11")
        self.in_class = QLineEdit("LoadImage")
        node_row.addRow("图片节点 ID", self.in_node)
        node_row.addRow("节点 class_type", self.in_class)
        self.sec_img.add_layout(node_row)
        v.addWidget(self.sec_img)
        self._on_mode_change()      # set initial visibility

        # ----- 提示词 -----
        self.sec_prompt = Collapsible("③ 提示词 / 尺寸", collapsed=False)
        self.in_prompt = QPlainTextEdit()
        self.in_prompt.setPlaceholderText("描述画面提示词...")
        self.in_prompt.setFixedHeight(54)
        self.sec_prompt.add(QLabel("正向提示词"))
        self.sec_prompt.add(self.in_prompt)

        pn = QFormLayout()
        self.in_prompt_node = QLineEdit("57")
        self.in_prompt_class = QLineEdit("CR Text")
        pn.addRow("提示词节点 ID", self.in_prompt_node)
        pn.addRow("提示词 class_type", self.in_prompt_class)
        self.sec_prompt.add_layout(pn)

        dim = QGridLayout()
        self.in_w = QSpinBox(); self.in_w.setRange(0, 8192); self.in_w.setValue(0)
        self.in_h = QSpinBox(); self.in_h.setRange(0, 8192); self.in_h.setValue(0)
        self.in_dim_node = QLineEdit()
        self.in_dim_class = QLineEdit("EmptyLatentImage")
        dim.addWidget(QLabel("宽"), 0, 0); dim.addWidget(self.in_w, 0, 1)
        dim.addWidget(QLabel("高"), 0, 2); dim.addWidget(self.in_h, 0, 3)
        self.sec_prompt.add(QLabel("输出尺寸（0 = 用工作流默认）"))
        self.sec_prompt.add_layout(dim)
        dn = QFormLayout()
        dn.addRow("尺寸节点 ID", self.in_dim_node)
        dn.addRow("尺寸 class_type", self.in_dim_class)
        self.sec_prompt.add_layout(dn)
        v.addWidget(self.sec_prompt)

        # ----- 高级 -----
        self.sec_adv = Collapsible("④ 高级（可选）", collapsed=True)
        af = QFormLayout()
        self.in_extra = QPlainTextEdit()
        self.in_extra.setPlaceholderText(
            '附加节点覆盖 JSON，例如:\n{"6":{"class_type":"CLIPTextEncode",'
            '"inputs":{"text":"a cat"}}}')
        self.in_extra.setFixedHeight(54)
        self.in_proxy = QLineEdit()
        self.in_proxy.setPlaceholderText("可选代理，如 http://127.0.0.1:7897")
        af.addRow("附加参数", self.in_extra)
        af.addRow("代理", self.in_proxy)
        self.sec_adv.add_layout(af)
        v.addWidget(self.sec_adv)

        # ----- 生成 -----
        self.btn = QPushButton("⚡ 生成")
        self.btn.setMinimumHeight(34)
        self.btn.clicked.connect(self.on_generate)
        v.addWidget(self.btn)

        self.bar = QProgressBar(); self.bar.setValue(0)
        v.addWidget(self.bar)

        # ----- 结果网格 -----
        self.sec_res = Collapsible("结果", collapsed=False)
        self.res_host = QWidget()
        self.res_grid = QGridLayout(self.res_host)
        self.res_grid.setContentsMargins(0, 0, 0, 0)
        self.sec_res.add(self.res_host)
        v.addWidget(self.sec_res)

        # ----- 日志 -----
        self.sec_log = Collapsible("日志", collapsed=True)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setFixedHeight(120)
        self.sec_log.add(self.log)
        v.addWidget(self.sec_log)

        v.addStretch(1)
        self.setWidget(scroll)

    # --- mode / upload -----------------------------------------------------
    def _on_mode_change(self):
        is_local = self.in_mode.currentData() == "local"
        self._upload_row_w.setVisible(is_local)
        self.lbl_thumb.setVisible(is_local)

    def on_pick_local(self):
        path, _ = QFileDialog.getOpenFileName(
            self.widget(), "选择参考图", "",
            "图片 (*.png *.jpg *.jpeg *.webp *.bmp)")
        if not path:
            return
        try:
            with open(path, "rb") as f:
                self.local_image = f.read()
            pm = pixmap_from_bytes(self.local_image, max_side=120)
            if pm:
                self.lbl_thumb.setPixmap(pm)
            self._log("已选择参考图 (%d KB)" % (len(self.local_image) // 1024), "ok")
        except Exception as e:
            self._log("读取图片失败: %s" % e, "err")

    def on_clear_local(self):
        self.local_image = None
        self.lbl_thumb.clear()
        self.lbl_thumb.setText("（未选择参考图）")

    # --- settings ----------------------------------------------------------
    _FIELDS = {
        "ak": "in_ak", "sk": "in_sk", "template": "in_template",
        "workflow": "in_workflow", "api": "in_api", "status": "in_status",
        "node": "in_node", "class": "in_class", "proxy": "in_proxy",
        "prompt_node": "in_prompt_node", "prompt_class": "in_prompt_class",
        "dim_node": "in_dim_node", "dim_class": "in_dim_class",
    }

    def _load_settings(self):
        k = Krita.instance()
        for key, attr in self._FIELDS.items():
            val = k.readSetting(SETTINGS_GROUP, key, "")
            if val:
                getattr(self, attr).setText(val)
        # collapse the config section if creds already exist
        if self.in_ak.text() and self.in_workflow.text():
            self.sec_cfg.toggle.setChecked(False)
            self.sec_cfg._on_toggle(False)

    def _save_settings(self):
        k = Krita.instance()
        for key, attr in self._FIELDS.items():
            k.writeSetting(SETTINGS_GROUP, key, getattr(self, attr).text())

    # --- logging -----------------------------------------------------------
    def _log(self, msg, level="info"):
        prefix = {"ok": "[OK] ", "warn": "[!] ", "err": "[X] "}.get(level, "")
        self.log.appendPlainText(prefix + msg)
        if level in ("err", "warn"):
            self.sec_log.toggle.setChecked(True)
            self.sec_log._on_toggle(True)

    def _progress(self, label, pct):
        self.bar.setValue(int(pct))
        self.bar.setFormat("%s %d%%" % (label, pct))

    # --- generate ----------------------------------------------------------
    def on_generate(self):
        if self.worker and self.worker.isRunning():
            return

        ak = self.in_ak.text().strip()
        sk = self.in_sk.text().strip()
        if not ak or not sk:
            self._log("请填写 AccessKey / SecretKey", "err"); return
        if not self.in_workflow.text().strip() or not self.in_template.text().strip():
            self._log("请填写 templateUuid 和 workflowUuid", "err"); return

        self._save_settings()

        # resolve reference image
        input_png = None
        mode = self.in_mode.currentData()
        if mode == "local":
            if not self.local_image:
                self._log("请先选择本地参考图", "err"); return
            input_png = self.local_image
        elif mode == "canvas":
            doc = Krita.instance().activeDocument()
            input_png = export_canvas_png(doc)
            if input_png is None:
                self._log("没有可用的画布（请先打开/新建文档）", "err"); return
            self._log("已读取画布 (%d KB)" % (len(input_png) // 1024), "info")

        w = self.in_w.value()
        h = self.in_h.value()
        cfg = {
            "ak": ak, "sk": sk,
            "template_uuid": self.in_template.text().strip(),
            "workflow_uuid": self.in_workflow.text().strip(),
            "api_url": self.in_api.text().strip() or DEFAULT_API,
            "status_url": self.in_status.text().strip() or DEFAULT_STATUS,
            "img_node": self.in_node.text().strip() or "11",
            "img_class": self.in_class.text().strip() or "LoadImage",
            "prompt": self.in_prompt.toPlainText().strip(),
            "prompt_node": self.in_prompt_node.text().strip() or "57",
            "prompt_class": self.in_prompt_class.text().strip() or "CR Text",
            "width": w if w > 0 else None,
            "height": h if h > 0 else None,
            "dim_node": self.in_dim_node.text().strip(),
            "dim_class": self.in_dim_class.text().strip() or "EmptyLatentImage",
            "extra_json": self.in_extra.toPlainText(),
            "proxy": self.in_proxy.text().strip(),
        }

        self.log.clear()
        self._clear_results()
        self._progress("开始", 1)
        self.btn.setEnabled(False)
        self.btn.setText("生成中...")

        self.worker = GenerateWorker(cfg, input_png)
        self.worker.sig_log.connect(self._log)
        self.worker.sig_progress.connect(self._progress)
        self.worker.sig_result.connect(self.on_result)
        self.worker.sig_error.connect(lambda m: self._log(m, "err"))
        self.worker.sig_done.connect(self.on_done)
        self.worker.start()

    # --- results -----------------------------------------------------------
    def _clear_results(self):
        while self.res_grid.count():
            item = self.res_grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def on_result(self, results):
        # results: list of (bytes, url) — runs on main thread
        self._clear_results()
        if not results:
            self._log("未获取到图片", "warn")
            return
        col_count = 2
        for i, (data, url) in enumerate(results):
            cell = QWidget()
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(2, 2, 2, 2)
            cl.setSpacing(3)

            thumb = QLabel()
            thumb.setAlignment(Qt.AlignCenter)
            pm = pixmap_from_bytes(data, max_side=130)
            if pm:
                thumb.setPixmap(pm)
            cl.addWidget(thumb)

            b1 = QPushButton("导入图层")
            b1.clicked.connect(lambda _, d=data: self._import_layer(d))
            b2 = QPushButton("新文档打开")
            b2.clicked.connect(lambda _, d=data: self._open_new(d))
            cl.addWidget(b1)
            cl.addWidget(b2)

            self.res_grid.addWidget(cell, i // col_count, i % col_count)
        self.sec_res.toggle.setChecked(True)
        self.sec_res._on_toggle(True)
        # auto-import first result into the active doc, like the PS plugin
        try:
            doc = Krita.instance().activeDocument()
            if doc is not None:
                insert_image_as_layer(doc, results[0][0])
                self._log("已自动导入第一张到当前画布", "ok")
        except Exception as e:
            self._log("自动导入失败: %s" % e, "warn")

    def _import_layer(self, data):
        try:
            doc = Krita.instance().activeDocument()
            if doc is None:
                self._open_new(data)
                return
            insert_image_as_layer(doc, data)
            self._log("已作为新图层导入", "ok")
        except Exception as e:
            self._log("导入失败: %s" % e, "err")

    def _open_new(self, data):
        try:
            open_image_in_new_doc(data)
            self._log("已在新文档打开", "ok")
        except Exception as e:
            self._log("打开失败: %s" % e, "err")

    def on_done(self):
        self.btn.setEnabled(True)
        self.btn.setText("⚡ 生成")

    def canvasChanged(self, canvas):
        pass
