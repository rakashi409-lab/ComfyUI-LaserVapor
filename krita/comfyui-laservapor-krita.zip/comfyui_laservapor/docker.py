"""Krita docker UI + background worker for ComfyUI-LaserVapor.

Feature parity with the original Photoshop UXP plugin:
  - upload a local reference image (file picker) OR use the current canvas
  - positive prompt -> CR Text node
  - input/output dimensions -> width/height node overrides
  - collapsible sections
  - results shown as a thumbnail grid, each with import / open-in-new-doc
"""
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor

from krita import Krita, DockWidget
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QObject, QEvent
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout, QLabel,
    QLineEdit, QPushButton, QComboBox, QPlainTextEdit, QProgressBar,
    QScrollArea, QSpinBox, QFileDialog, QToolButton, QFrame, QSizePolicy,
    QTabWidget,
)

from . import liblib
from .krita_io import (
    export_canvas_png, insert_image_as_layer, open_image_in_new_doc,
    pixmap_from_bytes,
)

DOCKER_ID = "comfyui_laservapor"
SETTINGS_GROUP = "ComfyUI-LaserVapor"
MAX_POLLS = 120
POLL_INTERVAL = 2.0

DEFAULT_API = "https://openapi.liblibai.cloud/api/generate/comfyui/app"
DEFAULT_STATUS = "https://openapi.liblibai.cloud/api/generate/comfy/status"


# ---------------------------------------------------------------------------
# 滚轮拦截: 让 SpinBox/ComboBox 不响应鼠标滚轮(滚页面时不会误改数值),
# 滚轮事件交还父级用于页面滚动。
# ---------------------------------------------------------------------------
class _NoWheel(QObject):
    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Wheel:
            ev.ignore()
            return True      # 吃掉滚轮, 不让控件处理
        return False


# ---------------------------------------------------------------------------
# Collapsible section widget
# ---------------------------------------------------------------------------
class Collapsible(QWidget):
    """A header button that shows/hides a content area below it."""

    def __init__(self, title, collapsed=False):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.toggle = QToolButton()
        self.toggle.setText(title)
        self.toggle.setCheckable(True)
        self.toggle.setChecked(not collapsed)
        self.toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toggle.setArrowType(Qt.DownArrow if not collapsed else Qt.RightArrow)
        self.toggle.clicked.connect(self._on_toggle)

        self.content = QFrame()
        self.content.setObjectName("card")
        self.content.setFrameShape(QFrame.StyledPanel)
        self.body = QVBoxLayout(self.content)
        self.body.setContentsMargins(8, 6, 8, 8)
        self.body.setSpacing(6)
        self.content.setVisible(not collapsed)

        lay.addWidget(self.toggle)
        lay.addWidget(self.content)

    def _on_toggle(self, checked):
        self.content.setVisible(checked)
        self.toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)

    def add(self, w):
        self.body.addWidget(w)

    def add_layout(self, l):
        self.body.addLayout(l)


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------
class GenerateWorker(QThread):
    sig_log = pyqtSignal(str, str)
    sig_progress = pyqtSignal(str, int)
    sig_result = pyqtSignal(list)         # list of (bytes, url)
    sig_error = pyqtSignal(str)
    sig_done = pyqtSignal()

    def __init__(self, cfg, input_png):
        super().__init__()
        self.cfg = cfg
        self.input_png = input_png

    def run(self):
        cfg = self.cfg
        proxy = cfg.get("proxy") or None
        try:
            gp = {"workflowUuid": cfg["workflow_uuid"]}

            # positive prompt -> CR Text node (original used node 57)
            if cfg.get("prompt"):
                gp[cfg["prompt_node"]] = {
                    "class_type": cfg["prompt_class"],
                    "inputs": {"text": cfg["prompt"]},
                }

            # output dimension overrides
            w, h = cfg.get("width"), cfg.get("height")
            if cfg.get("dim_node") and w and h:
                gp[cfg["dim_node"]] = {
                    "class_type": cfg["dim_class"],
                    "inputs": {"width": w, "height": h},
                }

            # input dimension overrides (参考图目标尺寸)
            iw, ih = cfg.get("in_width"), cfg.get("in_height")
            if cfg.get("idim_node") and iw and ih:
                gp[cfg["idim_node"]] = {
                    "class_type": cfg["idim_class"],
                    "inputs": {"width": iw, "height": ih},
                }

            # extra raw JSON overrides
            extra = cfg.get("extra_json", "").strip()
            if extra:
                try:
                    gp.update(json.loads(extra))
                except ValueError as e:
                    raise liblib.LibLibError("附加参数 JSON 格式错误: %s" % e)

            # reference image (local upload or canvas)
            if self.input_png:
                self.sig_progress.emit("正在上传图片...", 3)
                url = liblib.upload_image(
                    self.input_png, proxy=proxy, ak=cfg["ak"], sk=cfg["sk"],
                    log=lambda m, lv="info": self.sig_log.emit(m, lv))
                gp[cfg["img_node"]] = {
                    "class_type": cfg["img_class"],
                    "inputs": {"image": url},
                }
                self.sig_log.emit("图片已设置到节点 " + cfg["img_node"], "info")
            elif cfg.get("txt2img") and cfg.get("img_node"):
                # 文生图: 工作流的 LoadImage 是必填且不接受空值, 传一张纯白占位图,
                # 避免使用工作流发布时内置的那张参考图。
                pw = cfg.get("in_width") or cfg.get("width") or 1024
                ph = cfg.get("in_height") or cfg.get("height") or 1024
                self.sig_progress.emit("正在上传占位图...", 3)
                blank = liblib.solid_png(pw, ph, (255, 255, 255))
                url = liblib.upload_image(
                    blank, proxy=proxy, ak=cfg["ak"], sk=cfg["sk"],
                    log=lambda m, lv="info": self.sig_log.emit(m, lv))
                gp[cfg["img_node"]] = {
                    "class_type": cfg["img_class"],
                    "inputs": {"image": url},
                }
                self.sig_log.emit("文生图: 已用纯白占位图填入节点 " + cfg["img_node"], "info")

            self.sig_progress.emit("正在提交...", 5)
            self.sig_log.emit("工作流: " + cfg["workflow_uuid"][:12] + "...", "info")
            tid = liblib.generate(
                cfg["api_url"], cfg["template_uuid"], gp,
                cfg["ak"], cfg["sk"], proxy=proxy)
            self.sig_log.emit("任务已提交: " + str(tid)[:16] + "...", "ok")

            last_pct = 0
            for n in range(MAX_POLLS):
                # 自适应轮询: 首查快(0.6s)抓秒出任务; 越接近完成查得越勤,
                # 抓住出图那一刻不浪费尾部等待; 进度低时正常间隔省请求。
                if n == 0:
                    delay = 0.6
                elif last_pct >= 85:
                    delay = 0.6          # 快好了, 盯紧
                elif last_pct >= 50:
                    delay = 1.2
                else:
                    delay = min(1.0 + n * 0.2, 2.5)
                time.sleep(delay)
                st, pct, td = liblib.poll_once(
                    cfg["status_url"], tid, cfg["ak"], cfg["sk"], proxy=proxy)
                last_pct = pct
                self.sig_progress.emit("处理中...", max(pct, 6))
                self.sig_log.emit("#%d 状态=%s %d%%" % (n + 1, st, pct), "info")

                if liblib.is_finished(st):
                    urls = liblib.extract_urls(td)
                    if not urls:
                        raise liblib.LibLibError("任务完成但未找到图片 URL")
                    self.sig_log.emit("完成，共 %d 张图片" % len(urls), "ok")
                    self.sig_progress.emit("下载结果...", 98)
                    # 结果图在公开 CDN, 直连(不走代理)更快; 多张并发下载
                    def _dl(u):
                        try:
                            return (liblib.download(u), u)
                        except Exception as e:
                            self.sig_log.emit("下载失败 %s: %s" % (u, e), "warn")
                            return None
                    if len(urls) > 1:
                        with ThreadPoolExecutor(max_workers=4) as ex:
                            out = [r for r in ex.map(_dl, urls) if r]
                    else:
                        out = [r for r in (_dl(u) for u in urls) if r]
                    self.sig_result.emit(out)
                    self.sig_progress.emit("完成", 100)
                    return
                if liblib.is_failed(st):
                    fm = td.get("failedMessage") or td.get("errorMessage") \
                        or td.get("msg") or json.dumps(td)[:200]
                    raise liblib.LibLibError("任务失败: " + str(fm))

            raise liblib.LibLibError("轮询超时")
        except Exception as e:
            self.sig_error.emit(str(e))
        finally:
            self.sig_done.emit()


# ---------------------------------------------------------------------------
# DemoWorker — 走一遍生成进度, 然后把上传的图片作为结果返回。
# 复用与 GenerateWorker 相同的信号协议, 直接接到 docker 的
# _progress / on_result / _log / on_done 槽。
# ---------------------------------------------------------------------------
class DemoWorker(QThread):
    sig_log = pyqtSignal(str, str)
    sig_progress = pyqtSignal(str, int)
    sig_result = pyqtSignal(list)         # list of (bytes, url)
    sig_error = pyqtSignal(str)
    sig_done = pyqtSignal()

    def __init__(self, images):
        super().__init__()
        self.images = images          # list[bytes] — 本轮要"生成"的结果图

    def run(self):
        try:
            self.sig_log.emit("任务已提交，排队中...", "info")
            steps = [
                (6, "加载模型权重"), (15, "编码提示词"), (28, "构建潜空间"),
                (42, "采样 step 8/20"), (58, "采样 step 14/20"),
                (74, "采样 step 20/20"), (88, "VAE 解码"), (96, "后处理 / 超分"),
            ]
            for pct, label in steps:
                time.sleep(0.45)
                self.sig_progress.emit(label + "...", pct)
                self.sig_log.emit("[%3d%%] %s" % (pct, label), "info")
            self.sig_result.emit([(b, "result://generated") for b in self.images])
            self.sig_progress.emit("完成", 100)
            self.sig_log.emit("生成完成，共 %d 张" % len(self.images), "ok")
        except Exception as e:
            self.sig_error.emit(str(e))
        finally:
            self.sig_done.emit()


# ---------------------------------------------------------------------------
# Docker
# ---------------------------------------------------------------------------
class LaserVaporDocker(DockWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ComfyUI-LaserVapor")
        self.worker = None
        self.local_image = None       # bytes of a user-picked reference image
        self.demo_images = []         # list[bytes] uploaded into the AI-gen tab
        self.demo_index = 0           # round-robin cursor for each "generation"
        self.demo_undo_stack = []     # 每次演示生成压一条 {prev_index, layers:[node...]}
        self._demo_active = False     # on_result 是否来自演示生成
        self._had_error = False       # 本轮生成是否出错
        self._nowheel = _NoWheel(self)  # 滚轮拦截器(需长期持有引用)
        self._build_ui()
        self._load_settings()
        self._fit_tab_height()        # 初始页也按内容高度收紧

    # --- UI ----------------------------------------------------------------
    def _build_ui(self):
        root = QWidget()
        root.setObjectName("lvRoot")
        scroll = QScrollArea()
        scroll.setObjectName("lvScroll")
        scroll.setWidgetResizable(True)
        scroll.setWidget(root)

        v = QVBoxLayout(root)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)

        # ===================================================================
        # 品牌头部: logo + 名称(与品牌站同一 logo, 透明底 PNG)
        # ===================================================================
        header = QHBoxLayout()
        header.setSpacing(10)
        logo = QLabel()
        logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
        pm = QPixmap(logo_path)
        if not pm.isNull():
            # 按屏幕像素比渲染高清 logo, 避免在 HiDPI 屏上发糊
            try:
                dpr = self.devicePixelRatioF()
            except Exception:
                dpr = 1.0
            side = 36
            hi = pm.scaled(int(side * dpr), int(side * dpr),
                           Qt.KeepAspectRatio, Qt.SmoothTransformation)
            hi.setDevicePixelRatio(dpr)
            logo.setPixmap(hi)
        logo.setFixedSize(36, 36)
        logo.setStyleSheet("background: transparent; border: none;")
        logo.setAlignment(Qt.AlignCenter)
        header.addWidget(logo)

        title_box = QVBoxLayout()
        title_box.setSpacing(0)
        t_zh = QLabel("农用激光除杂车")
        t_zh.setStyleSheet(
            "color:#eaf6f7; font-size:15px; font-weight:bold; background:transparent;")
        t_en = QLabel("LASER VAPOR · AI 生成")
        t_en.setStyleSheet(
            "color:#3fbdb0; font-size:10px; letter-spacing:1px; background:transparent;")
        title_box.addWidget(t_zh)
        title_box.addWidget(t_en)
        header.addLayout(title_box)
        header.addStretch(1)
        _header_w = QWidget()
        _header_w.setLayout(header)
        _header_w.setStyleSheet("background: transparent;")
        v.addWidget(_header_w)

        # ===================================================================
        # 顶部 Tab: 两个独立的生成板块, 互不混淆
        #   Tab1「☁ 云端生成」 = 真 LibLib AI 生成
        #   Tab2「✦ AI 生成」 = 上传素材 → 走生成流程 → 出图
        # 进度条 / 结果 / 日志放在 Tab 下方, 两个板块共用。
        # ===================================================================
        self.tabs = QTabWidget()
        # 让 QTabWidget 高度跟随当前页内容(非当前页不占高度), 避免 tab 被拉满
        # 后在 tab 与下方共用区之间撑出空隙。
        self.tabs.currentChanged.connect(self._fit_tab_height)
        v.addWidget(self.tabs)

        # -------------------------------------------------------------------
        # Tab1: 云端生成
        # -------------------------------------------------------------------
        tab_cloud = QWidget()
        cv = QVBoxLayout(tab_cloud)
        cv.setContentsMargins(2, 6, 2, 6)
        cv.setSpacing(6)

        # ----- ① 图片输入 -----
        self.sec_img = Collapsible("① 图片输入（图生图，可选）", collapsed=False)
        self.in_mode = QComboBox()
        self.in_mode.setFocusPolicy(Qt.StrongFocus)
        self.in_mode.installEventFilter(self._nowheel)
        self.in_mode.addItem("不使用图片（文生图）", "none")
        self.in_mode.addItem("上传本地图片", "local")
        self.in_mode.addItem("使用当前画布", "canvas")
        self.in_mode.currentIndexChanged.connect(self._on_mode_change)
        self.sec_img.add(self.in_mode)

        upload_row = QHBoxLayout()
        self.btn_upload = QPushButton("选择参考图...")
        self.btn_upload.clicked.connect(self.on_pick_local)
        self.btn_clear_img = QPushButton("清除")
        self.btn_clear_img.clicked.connect(self.on_clear_local)
        upload_row.addWidget(self.btn_upload)
        upload_row.addWidget(self.btn_clear_img)
        self._upload_row_w = QWidget(); self._upload_row_w.setLayout(upload_row)
        self.sec_img.add(self._upload_row_w)

        self.lbl_thumb = QLabel("（未选择参考图）")
        self.lbl_thumb.setAlignment(Qt.AlignCenter)
        self.lbl_thumb.setMinimumHeight(70)
        self.lbl_thumb.setStyleSheet("color:#888;border:1px dashed #555;border-radius:6px;")
        self.sec_img.add(self.lbl_thumb)
        cv.addWidget(self.sec_img)
        self._on_mode_change()      # set initial visibility

        # ----- ② 提示词 -----
        self.sec_prompt = Collapsible("② 提示词", collapsed=False)
        self.in_prompt = QPlainTextEdit()
        self.in_prompt.setPlaceholderText("描述画面提示词...")
        self.in_prompt.setFixedHeight(60)
        self.sec_prompt.add(self.in_prompt)
        cv.addWidget(self.sec_prompt)

        # ----- ③ 尺寸（输入 + 输出，可手动改 + 预设） -----
        self.sec_size = Collapsible("③ 尺寸", collapsed=False)
        self.in_iw = QSpinBox(); self.in_iw.setRange(0, 8192); self.in_iw.setValue(0)
        self.in_ih = QSpinBox(); self.in_ih.setRange(0, 8192); self.in_ih.setValue(0)
        self.in_w = QSpinBox(); self.in_w.setRange(0, 8192); self.in_w.setValue(0)
        self.in_h = QSpinBox(); self.in_h.setRange(0, 8192); self.in_h.setValue(0)
        for sb in (self.in_iw, self.in_ih, self.in_w, self.in_h):
            sb.setMinimumHeight(28)
            sb.setMinimumWidth(78)
            sb.setSingleStep(8)
            sb.setAlignment(Qt.AlignCenter)
            sb.setButtonSymbols(QSpinBox.NoButtons)   # 去掉上下箭头, 更清爽
            sb.setFocusPolicy(Qt.StrongFocus)         # 仅点击/Tab 聚焦, 滚轮不聚焦
            sb.installEventFilter(self._nowheel)       # 滚页面不误改数值

        self.sec_size.add(QLabel("0 = 用工作流默认；点预设快速填入，也可手动修改"))

        # 输入尺寸(参考图 resize)
        irow = QHBoxLayout()
        irow.addWidget(QLabel("输入"))
        irow.addWidget(QLabel("宽")); irow.addWidget(self.in_iw)
        irow.addWidget(QLabel("高")); irow.addWidget(self.in_ih)
        _iw = QWidget(); _iw.setLayout(irow)
        self.sec_size.add(_iw)
        self.sec_size.add(self._preset_row(self.in_iw, self.in_ih))

        # 输出尺寸(生成图)
        orow = QHBoxLayout()
        orow.addWidget(QLabel("输出"))
        orow.addWidget(QLabel("宽")); orow.addWidget(self.in_w)
        orow.addWidget(QLabel("高")); orow.addWidget(self.in_h)
        _ow = QWidget(); _ow.setLayout(orow)
        self.sec_size.add(_ow)
        self.sec_size.add(self._preset_row(self.in_w, self.in_h))
        cv.addWidget(self.sec_size)

        # ----- ④ 配置（密钥 / 节点 / URL，单独收起） -----
        self.sec_cfg = Collapsible("④ 配置（密钥 / 节点 / URL）", collapsed=True)
        form = QFormLayout()
        form.setContentsMargins(0, 0, 0, 0)
        self.in_ak = QLineEdit()
        self.in_sk = QLineEdit(); self.in_sk.setEchoMode(QLineEdit.Password)
        self.in_template = QLineEdit()
        self.in_workflow = QLineEdit()
        self.in_api = QLineEdit(DEFAULT_API)
        self.in_status = QLineEdit(DEFAULT_STATUS)
        self.in_node = QLineEdit("11")
        self.in_class = QLineEdit("LoadImage")
        self.in_prompt_node = QLineEdit("57")
        self.in_prompt_class = QLineEdit("CR Text")
        self.in_dim_node = QLineEdit()
        self.in_dim_class = QLineEdit("EmptyLatentImage")
        self.in_idim_node = QLineEdit()
        self.in_idim_class = QLineEdit("EmptyLatentImage")
        self.in_extra = QPlainTextEdit()
        self.in_extra.setPlaceholderText(
            '附加节点覆盖 JSON，例如:\n{"6":{"class_type":"CLIPTextEncode",'
            '"inputs":{"text":"a cat"}}}')
        self.in_extra.setFixedHeight(50)
        self.in_proxy = QLineEdit()
        self.in_proxy.setPlaceholderText("可选代理，如 http://127.0.0.1:7897")
        form.addRow("AccessKey", self.in_ak)
        form.addRow("SecretKey", self.in_sk)
        form.addRow("templateUuid", self.in_template)
        form.addRow("workflowUuid", self.in_workflow)
        form.addRow("图片节点 ID", self.in_node)
        form.addRow("图片 class", self.in_class)
        form.addRow("提示词节点 ID", self.in_prompt_node)
        form.addRow("提示词 class", self.in_prompt_class)
        form.addRow("输出尺寸节点 ID", self.in_dim_node)
        form.addRow("输出尺寸 class", self.in_dim_class)
        form.addRow("输入尺寸节点 ID", self.in_idim_node)
        form.addRow("输入尺寸 class", self.in_idim_class)
        form.addRow("API URL", self.in_api)
        form.addRow("Status URL", self.in_status)
        form.addRow("附加参数", self.in_extra)
        form.addRow("代理", self.in_proxy)
        self.sec_cfg.add_layout(form)
        cv.addWidget(self.sec_cfg)

        # ----- 云端生成按钮 -----
        self.btn = QPushButton("⚡ 云端生成")
        self.btn.setObjectName("genBtn")
        self.btn.setMinimumHeight(36)
        self.btn.clicked.connect(self.on_generate)
        cv.addWidget(self.btn)
        self.tabs.addTab(tab_cloud, "☁ 云端生成")

        # -------------------------------------------------------------------
        # Tab2: AI 生成
        #   顺序: 提示词 → 尺寸/数量 → 生成 → 撤回 → 生成历史(最底部)
        # -------------------------------------------------------------------
        tab_demo = QWidget()
        dv = QVBoxLayout(tab_demo)
        dv.setContentsMargins(2, 6, 2, 6)
        dv.setSpacing(8)

        dv.addWidget(QLabel("正向提示词"))
        self.in_demo_prompt = QPlainTextEdit()
        self.in_demo_prompt.setPlaceholderText("描述你想要生成的画面，如：一只在花丛中的橘猫，电影感光影...")
        self.in_demo_prompt.setFixedHeight(66)
        dv.addWidget(self.in_demo_prompt)

        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("尺寸"))
        self.in_demo_size = QComboBox()
        self.in_demo_size.setFocusPolicy(Qt.StrongFocus)
        self.in_demo_size.installEventFilter(self._nowheel)
        for s in ["1024 × 1024（1:1）", "832 × 1216（2:3）", "1216 × 832（3:2）",
                  "768 × 1344（9:16）", "1344 × 768（16:9）"]:
            self.in_demo_size.addItem(s)
        size_row.addWidget(self.in_demo_size, 1)
        size_row.addWidget(QLabel("数量"))
        self.in_demo_count = QSpinBox()
        self.in_demo_count.setRange(1, 4); self.in_demo_count.setValue(1)
        self.in_demo_count.setFocusPolicy(Qt.StrongFocus)
        self.in_demo_count.installEventFilter(self._nowheel)
        size_row.addWidget(self.in_demo_count)
        _size_w = QWidget(); _size_w.setLayout(size_row)
        dv.addWidget(_size_w)

        self.btn_demo = QPushButton("⚡ 生成")
        self.btn_demo.setObjectName("genBtn")
        self.btn_demo.setMinimumHeight(36)
        self.btn_demo.clicked.connect(self.on_generate_demo)
        dv.addWidget(self.btn_demo)

        self.btn_demo_undo = QPushButton("↩ 撤回上一步")
        self.btn_demo_undo.setObjectName("undoBtn")
        self.btn_demo_undo.clicked.connect(self.on_undo_demo)
        self.btn_demo_undo.setEnabled(False)
        dv.addWidget(self.btn_demo_undo)

        # ----- 「生成历史」折叠区(放最底部): 上传/清空按钮 + 缩略图网格 -----
        # 默认收起; 展开才见上传入口, 更隐蔽。网格限高, 避免撑出大空白。
        self.sec_history = Collapsible("🕘 生成历史", collapsed=True)
        hist_row = QHBoxLayout()
        self.btn_demo_pick = QPushButton("上传图片...")
        self.btn_demo_pick.clicked.connect(self.on_pick_demo)
        self.btn_demo_clear = QPushButton("清空")
        self.btn_demo_clear.clicked.connect(self.on_clear_demo)
        hist_row.addWidget(self.btn_demo_pick)
        hist_row.addWidget(self.btn_demo_clear)
        self.sec_history.add_layout(hist_row)

        hist_scroll = QScrollArea()
        hist_scroll.setWidgetResizable(True)
        hist_scroll.setMaximumHeight(220)
        hist_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.demo_host = QWidget()
        self.demo_grid = QGridLayout(self.demo_host)
        self.demo_grid.setContentsMargins(0, 0, 0, 0)
        self.demo_grid.setSpacing(4)
        self.demo_grid.setAlignment(Qt.AlignTop)
        hist_scroll.setWidget(self.demo_host)
        self.sec_history.add(hist_scroll)
        dv.addWidget(self.sec_history)
        self._refresh_demo_history()      # 初始占位提示
        self.tabs.addTab(tab_demo, "✦ AI 生成")

        # ===================================================================
        # 共用区: 进度条 / 结果网格 / 日志
        # ===================================================================
        self.bar = QProgressBar(); self.bar.setValue(0)
        v.addWidget(self.bar)

        # ----- 结果网格 -----
        self.sec_res = Collapsible("🖼 结果", collapsed=False)
        self.res_host = QWidget()
        self.res_grid = QGridLayout(self.res_host)
        self.res_grid.setContentsMargins(0, 0, 0, 0)
        self.sec_res.add(self.res_host)
        v.addWidget(self.sec_res)

        # ----- 日志 -----
        self.sec_log = Collapsible("📄 日志", collapsed=True)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setFixedHeight(150)
        self.log.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        self.sec_log.add(self.log)
        log_btns = QHBoxLayout()
        self.btn_log_copy = QPushButton("复制日志")
        self.btn_log_copy.clicked.connect(self._copy_log)
        self.btn_log_clear = QPushButton("清空")
        self.btn_log_clear.clicked.connect(lambda: self.log.clear())
        log_btns.addWidget(self.btn_log_copy)
        log_btns.addWidget(self.btn_log_clear)
        self.sec_log.add_layout(log_btns)
        v.addWidget(self.sec_log)

        v.addStretch(1)

        # ===== 深空科技主题 QSS (与品牌站同调: 深底 + 青→蓝渐变) =====
        root.setStyleSheet("""
            /* ---- 深蓝底(只命中 root/scroll 两个控件, 不级联子控件, 不卡) ---- */
            QWidget#lvRoot {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #0b2030, stop:0.5 #08161f, stop:1 #050d14);
            }
            QScrollArea#lvScroll { background: transparent; border: none; }
            QScrollArea#lvScroll > QWidget > QWidget { background: transparent; }
            /* ---- Tab ---- */
            QTabWidget::pane {
                border: 1px solid #16323f; border-radius: 10px;
                background: #0d1f2b; top: -1px;
            }
            QTabBar::tab {
                padding: 7px 22px; margin-right: 4px; min-width: 72px;
                color: #7fa8b5; background: #0c1c27;
                border: 1px solid #16323f; border-bottom: none;
                border-top-left-radius: 9px; border-top-right-radius: 9px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                color: #ffffff; background: #2f7aaf; border-color: transparent;
            }
            /* ---- 文字标签 ---- */
            QLabel { color: #9fc2cb; background: transparent; }
            /* ---- 折叠标题 ---- */
            QToolButton {
                color: #cfe5e8; background: transparent; border: none;
                font-weight: bold; text-align: left; padding: 6px 2px;
            }
            QToolButton:hover { color: #3fbdb0; }
            /* ---- 输入框 / 多行 ---- */
            QLineEdit, QPlainTextEdit, QComboBox, QSpinBox {
                background: #0a1822; color: #eaf6f7;
                border: 1px solid #1d3d49; border-radius: 8px;
                padding: 5px 8px;
            }
            QLineEdit:focus, QPlainTextEdit:focus,
            QComboBox:focus, QSpinBox:focus { border: 1px solid #3fbdb0; }
            QComboBox::drop-down { border: none; width: 20px; }
            QComboBox QAbstractItemView {
                background: #0d1f2b; color: #eaf6f7;
                border: 1px solid #1d3d49; selection-background-color: #2f7aaf;
                outline: none;
            }
            QPlainTextEdit { font-family: 'Consolas','JetBrains Mono',monospace; }
            /* ---- 折叠区内容卡片 ---- */
            QFrame#card { border: 1px solid #16323f; border-radius: 10px; background: #0b1b26; }
            /* ---- 主生成按钮: 品牌渐变 ---- */
            QPushButton#genBtn {
                color: #ffffff; font-weight: bold; font-size: 14px;
                border: none; border-radius: 10px; padding: 8px;
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #3fbdb0, stop:1 #2f7aaf);
            }
            QPushButton#genBtn:hover { background: #3a8bc6; }
            QPushButton#genBtn:disabled { color: #9fc2cb; background: #234f50; }
            /* ---- 撤回按钮 ---- */
            QPushButton#undoBtn {
                color: #9fc7cf; background: transparent;
                border: 1px solid #2a525a; border-radius: 9px; padding: 6px;
            }
            QPushButton#undoBtn:hover { color:#cfe9ee; border-color:#3fbdb0; }
            QPushButton#undoBtn:disabled { color:#3a4f55; border-color:#1c2e34; }
            /* ---- 普通次级按钮 ---- */
            QPushButton {
                color: #cfe5e8; background: #122a36;
                border: 1px solid #1d3d49; border-radius: 8px; padding: 6px 10px;
            }
            QPushButton:hover { border-color: #3fbdb0; }
            /* ---- 尺寸预设小按钮 ---- */
            QPushButton#presetBtn {
                color: #9fc7cf; background: #0f2530;
                border: 1px solid #1d3d49; border-radius: 6px;
                padding: 3px 4px; font-weight: bold;
            }
            QPushButton#presetBtn:hover { color: #ffffff; border-color: #3fbdb0; }
            /* ---- 进度条 ---- */
            QProgressBar {
                border: 1px solid #1d3d49; border-radius: 9px;
                text-align: center; color: #eaf6f7; height: 24px;
                background: #0a1822; font-weight: bold;
            }
            QProgressBar::chunk {
                border-radius: 8px;
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #3fbdb0, stop:1 #2f7aaf);
            }
        """)
        self.setWidget(scroll)

    # --- size presets ------------------------------------------------------
    _PRESETS = [
        ("1:1", 1024, 1024),
        ("2:3", 832, 1216),
        ("3:2", 1216, 832),
        ("9:16", 1152, 2048),
        ("16:9", 2048, 1152),
    ]

    def _preset_row(self, sb_w, sb_h):
        """返回一排预设按钮; 点击把对应宽高填入给定的两个 SpinBox。"""
        row = QHBoxLayout()
        row.setSpacing(4)
        for label, w, h in self._PRESETS:
            b = QPushButton(label)
            b.setObjectName("presetBtn")
            b.setMinimumHeight(24)
            b.clicked.connect(
                lambda _=False, ww=w, hh=h: (sb_w.setValue(ww), sb_h.setValue(hh)))
            row.addWidget(b)
        host = QWidget()
        host.setLayout(row)
        return host

    # --- tab height auto-fit -----------------------------------------------
    def _fit_tab_height(self, *_):
        """让 QTabWidget 只按当前页高度撑开, 其余页不占高度。
        这样切换 tab 后, tab 与下方共用区(结果/日志)之间不会留空隙。"""
        cur = self.tabs.currentIndex()
        for i in range(self.tabs.count()):
            w = self.tabs.widget(i)
            if w is None:
                continue
            sp = w.sizePolicy()
            sp.setVerticalPolicy(
                QSizePolicy.Preferred if i == cur else QSizePolicy.Ignored)
            w.setSizePolicy(sp)
        cw = self.tabs.currentWidget()
        if cw is not None:
            cw.adjustSize()
        self.tabs.updateGeometry()

    # --- mode / upload -----------------------------------------------------
    def _on_mode_change(self):
        is_local = self.in_mode.currentData() == "local"
        self._upload_row_w.setVisible(is_local)
        self.lbl_thumb.setVisible(is_local)

    def on_pick_local(self):
        path, _ = QFileDialog.getOpenFileName(
            self.widget(), "选择参考图", "",
            "图片 (*.png *.jpg *.jpeg *.webp *.bmp)")
        if not path:
            return
        try:
            with open(path, "rb") as f:
                self.local_image = f.read()
            pm = pixmap_from_bytes(self.local_image, max_side=120)
            if pm:
                self.lbl_thumb.setPixmap(pm)
            self._log("已选择参考图 (%d KB)" % (len(self.local_image) // 1024), "ok")
        except Exception as e:
            self._log("读取图片失败: %s" % e, "err")

    def on_clear_local(self):
        self.local_image = None
        self.lbl_thumb.clear()
        self.lbl_thumb.setText("（未选择参考图）")

    # --- AI 生成 tab --------------------------------------------------------
    def on_pick_demo(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self.widget(), "上传图片（可多选）", "",
            "图片 (*.png *.jpg *.jpeg *.webp *.bmp)")
        if not paths:
            return
        added = 0
        for path in paths:
            try:
                with open(path, "rb") as f:
                    self.demo_images.append(f.read())
                added += 1
            except Exception as e:
                self._log("读取失败 %s: %s" % (path, e), "warn")
        if added:
            self._refresh_demo_history()
            self._log("已上传 %d 张图片" % added, "ok")

    def on_clear_demo(self):
        self.demo_images = []
        self.demo_index = 0
        self.demo_undo_stack = []
        self.btn_demo_undo.setEnabled(False)
        self._refresh_demo_history()

    def on_undo_demo(self):
        """撤回上一步: 删除上次导入画布的图层, 游标回退, 清结果区。"""
        if not self.demo_undo_stack:
            self.btn_demo_undo.setEnabled(False)
            return
        entry = self.demo_undo_stack.pop()

        # 1) 删除上次导入的图层
        removed = 0
        doc = Krita.instance().activeDocument()
        for layer in entry.get("layers", []):
            try:
                parent = layer.parentNode()
                if parent is not None:
                    parent.removeChildNode(layer)
                else:
                    layer.remove()
                removed += 1
            except Exception as e:
                self._log("移除图层失败: %s" % e, "warn")
        if doc is not None:
            doc.refreshProjection()

        # 2) 游标回退到这步之前
        self.demo_index = entry.get("prev_index", 0)

        # 3) 清结果区, 刷新历史高亮
        self._clear_results()
        self._progress("就绪", 0)
        self._refresh_demo_history()
        self.btn_demo_undo.setEnabled(bool(self.demo_undo_stack))
        self._log("已撤回上一步（移除 %d 个图层）" % removed, "ok")

    def _refresh_demo_history(self):
        """重绘「生成历史」缩略图网格，按上传顺序标序号。"""
        while self.demo_grid.count():
            item = self.demo_grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        if not self.demo_images:
            ph = QLabel("（暂无内容，点上方「上传图片」添加）")
            ph.setAlignment(Qt.AlignCenter)
            ph.setMinimumHeight(70)
            ph.setStyleSheet("color:#888;border:1px dashed #555;border-radius:6px;")
            self.demo_grid.addWidget(ph, 0, 0)
            self.sec_history.toggle.setText("🕘 生成历史")
            return
        col_count = 3
        nxt = self.demo_index % len(self.demo_images)   # 下次生成会取的序号
        for i, data in enumerate(self.demo_images):
            cell = QWidget()
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)

            thumb = QLabel()
            thumb.setAlignment(Qt.AlignCenter)
            pm = pixmap_from_bytes(data, max_side=86)
            if pm:
                thumb.setPixmap(pm)
            is_next = (i == nxt)
            thumb.setStyleSheet(
                "border:2px solid %s;border-radius:6px;padding:2px;"
                % ("#3fbdb0" if is_next else "#444"))
            cl.addWidget(thumb)

            tag = QLabel("#%d%s" % (i + 1, "  ▶ 下一张" if is_next else ""))
            tag.setAlignment(Qt.AlignCenter)
            tag.setStyleSheet(
                "color:%s;font-size:11px;font-weight:bold;"
                % ("#3fbdb0" if is_next else "#9aa"))
            cl.addWidget(tag)

            self.demo_grid.addWidget(cell, i // col_count, i % col_count)
        self.sec_history.toggle.setText("🕘 生成历史（%d）" % len(self.demo_images))

    # --- settings ----------------------------------------------------------
    _FIELDS = {
        "ak": "in_ak", "sk": "in_sk", "template": "in_template",
        "workflow": "in_workflow", "api": "in_api", "status": "in_status",
        "node": "in_node", "class": "in_class", "proxy": "in_proxy",
        "prompt_node": "in_prompt_node", "prompt_class": "in_prompt_class",
        "dim_node": "in_dim_node", "dim_class": "in_dim_class",
        "idim_node": "in_idim_node", "idim_class": "in_idim_class",
    }

    def _load_settings(self):
        k = Krita.instance()
        for key, attr in self._FIELDS.items():
            val = k.readSetting(SETTINGS_GROUP, key, "")
            if val:
                getattr(self, attr).setText(val)
        # collapse the config section if creds already exist
        if self.in_ak.text() and self.in_workflow.text():
            self.sec_cfg.toggle.setChecked(False)
            self.sec_cfg._on_toggle(False)

    def _save_settings(self):
        k = Krita.instance()
        for key, attr in self._FIELDS.items():
            k.writeSetting(SETTINGS_GROUP, key, getattr(self, attr).text())

    # --- logging -----------------------------------------------------------
    def _log(self, msg, level="info"):
        prefix = {"ok": "[OK] ", "warn": "[!] ", "err": "[X] "}.get(level, "")
        self.log.appendPlainText(prefix + msg)
        if level in ("err", "warn"):
            self.sec_log.toggle.setChecked(True)
            self.sec_log._on_toggle(True)

    def _copy_log(self):
        from PyQt5.QtWidgets import QApplication
        QApplication.clipboard().setText(self.log.toPlainText())
        self._log("日志已复制到剪贴板", "ok")

    def _progress(self, label, pct):
        self.bar.setValue(int(pct))
        self.bar.setFormat("%s %d%%" % (label, pct))

    def _on_error(self, msg):
        """生成出错: 记日志 + 进度条变红显示失败。"""
        self._had_error = True
        self._log(msg, "err")
        self.bar.setFormat("✕ 失败")
        self.bar.setStyleSheet(
            "QProgressBar{border:1px solid #5a2230;border-radius:9px;"
            "text-align:center;color:#ffd9d9;height:24px;background:#2a1216;"
            "font-weight:bold;}"
            "QProgressBar::chunk{border-radius:8px;"
            "background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 #c0392b,stop:1 #e74c3c);}")

    def _reset_bar_style(self):
        """恢复进度条为品牌色(下次生成开始时调用)。"""
        self.bar.setStyleSheet("")   # 清除内联, 回到全局 QSS

    # --- generate ----------------------------------------------------------
    def on_generate(self):
        if self.worker and self.worker.isRunning():
            return

        ak = self.in_ak.text().strip()
        sk = self.in_sk.text().strip()
        if not ak or not sk:
            self._log("请填写 AccessKey / SecretKey", "err"); return
        if not self.in_workflow.text().strip() or not self.in_template.text().strip():
            self._log("请填写 templateUuid 和 workflowUuid", "err"); return

        self._save_settings()

        # resolve reference image
        input_png = None
        mode = self.in_mode.currentData()
        if mode == "local":
            if not self.local_image:
                self._log("请先选择本地参考图", "err"); return
            input_png = self.local_image
        elif mode == "canvas":
            doc = Krita.instance().activeDocument()
            input_png = export_canvas_png(doc)
            if input_png is None:
                self._log("没有可用的画布（请先打开/新建文档）", "err"); return
            self._log("已读取画布 (%d KB)" % (len(input_png) // 1024), "info")

        w = self.in_w.value()
        h = self.in_h.value()
        iw = self.in_iw.value()
        ih = self.in_ih.value()
        cfg = {
            "ak": ak, "sk": sk,
            "template_uuid": self.in_template.text().strip(),
            "workflow_uuid": self.in_workflow.text().strip(),
            "api_url": self.in_api.text().strip() or DEFAULT_API,
            "status_url": self.in_status.text().strip() or DEFAULT_STATUS,
            "img_node": self.in_node.text().strip() or "11",
            "img_class": self.in_class.text().strip() or "LoadImage",
            "txt2img": (mode == "none"),
            "prompt": self.in_prompt.toPlainText().strip(),
            "prompt_node": self.in_prompt_node.text().strip() or "57",
            "prompt_class": self.in_prompt_class.text().strip() or "CR Text",
            "width": w if w > 0 else None,
            "height": h if h > 0 else None,
            "dim_node": self.in_dim_node.text().strip(),
            "dim_class": self.in_dim_class.text().strip() or "EmptyLatentImage",
            "in_width": iw if iw > 0 else None,
            "in_height": ih if ih > 0 else None,
            "idim_node": self.in_idim_node.text().strip(),
            "idim_class": self.in_idim_class.text().strip() or "EmptyLatentImage",
            "extra_json": self.in_extra.toPlainText(),
            "proxy": self.in_proxy.text().strip(),
        }

        self.log.clear()
        self._clear_results()
        self._had_error = False
        self._reset_bar_style()
        self._progress("开始", 1)
        self.btn.setEnabled(False)
        self.btn.setText("生成中...")
        self.btn_demo.setEnabled(False)

        self.worker = GenerateWorker(cfg, input_png)
        self.worker.sig_log.connect(self._log)
        self.worker.sig_progress.connect(self._progress)
        self.worker.sig_result.connect(self.on_result)
        self.worker.sig_error.connect(self._on_error)
        self.worker.sig_done.connect(self.on_done)
        self.worker.start()

    # --- generate (AI 生成 tab) --------------------------------------------
    def on_generate_demo(self):
        if self.worker and self.worker.isRunning():
            return
        if not self.demo_images:
            self._log("请先上传图片", "err"); return

        # 按「数量」从上传池里顺序取 N 张, 跨多次生成循环推进游标
        n = self.in_demo_count.value()
        pool = self.demo_images
        picked = [pool[(self.demo_index + k) % len(pool)] for k in range(n)]
        prev_index = self.demo_index
        self.demo_index = (self.demo_index + n) % len(pool)

        # 压入撤回栈: 记录这步之前的游标; 导入的图层等 on_result 回填
        self.demo_undo_stack.append({"prev_index": prev_index, "layers": []})
        self._demo_active = True

        # 收起「生成历史」, 让生成过程更像真在出图
        self.sec_history.toggle.setChecked(False)
        self.sec_history._on_toggle(False)

        self.log.clear()
        self._clear_results()
        self._had_error = False
        self._reset_bar_style()
        self._progress("开始", 1)
        self.btn.setEnabled(False)
        self.btn_demo.setEnabled(False)
        self.btn_demo.setText("生成中...")
        self.btn_demo_undo.setEnabled(False)

        self.worker = DemoWorker(picked)
        self.worker.sig_log.connect(self._log)
        self.worker.sig_progress.connect(self._progress)
        self.worker.sig_result.connect(self.on_result)
        self.worker.sig_error.connect(self._on_error)
        self.worker.sig_done.connect(self.on_done)
        self.worker.start()

    # --- results -----------------------------------------------------------
    def _clear_results(self):
        while self.res_grid.count():
            item = self.res_grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def on_result(self, results):
        # results: list of (bytes, url) — runs on main thread
        self._clear_results()
        if not results:
            self._log("未获取到图片", "warn")
            return
        col_count = 2
        for i, (data, url) in enumerate(results):
            cell = QWidget()
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(2, 2, 2, 2)
            cl.setSpacing(3)

            thumb = QLabel()
            thumb.setAlignment(Qt.AlignCenter)
            pm = pixmap_from_bytes(data, max_side=130)
            if pm:
                thumb.setPixmap(pm)
            cl.addWidget(thumb)

            b1 = QPushButton("导入图层")
            b1.clicked.connect(lambda _, d=data: self._import_layer(d))
            b2 = QPushButton("新文档打开")
            b2.clicked.connect(lambda _, d=data: self._open_new(d))
            cl.addWidget(b1)
            cl.addWidget(b2)

            self.res_grid.addWidget(cell, i // col_count, i % col_count)
        self.sec_res.toggle.setChecked(True)
        self.sec_res._on_toggle(True)

        if self._demo_active:
            # 演示生成: 把所有结果图导入画布, 并把图层记入撤回栈
            self._demo_active = False
            entry = self.demo_undo_stack[-1] if self.demo_undo_stack else None
            doc = Krita.instance().activeDocument()
            if doc is None:
                self._log("没有打开的文档，结果未导入画布", "warn")
            else:
                for j, (data, _u) in enumerate(results):
                    try:
                        layer = insert_image_as_layer(doc, data)
                        if entry is not None and layer is not None:
                            entry["layers"].append(layer)
                    except Exception as e:
                        self._log("导入第 %d 张失败: %s" % (j + 1, e), "warn")
                self._log("已导入 %d 张到当前画布" % len(results), "ok")
            self.btn_demo_undo.setEnabled(bool(self.demo_undo_stack))
            self._refresh_demo_history()   # 更新「下一张」高亮
            return

        # 云端生成: 自动导入第一张到当前画布(原行为)
        try:
            doc = Krita.instance().activeDocument()
            if doc is not None:
                insert_image_as_layer(doc, results[0][0])
                self._log("已自动导入第一张到当前画布", "ok")
        except Exception as e:
            self._log("自动导入失败: %s" % e, "warn")

    def _import_layer(self, data):
        try:
            doc = Krita.instance().activeDocument()
            if doc is None:
                self._open_new(data)
                return
            insert_image_as_layer(doc, data)
            self._log("已作为新图层导入", "ok")
        except Exception as e:
            self._log("导入失败: %s" % e, "err")

    def _open_new(self, data):
        try:
            open_image_in_new_doc(data)
            self._log("已在新文档打开", "ok")
        except Exception as e:
            self._log("打开失败: %s" % e, "err")

    def on_done(self):
        self.btn.setEnabled(True)
        self.btn.setText("⚡ 云端生成")
        self.btn_demo.setEnabled(True)
        self.btn_demo.setText("⚡ 生成")

    def canvasChanged(self, canvas):
        pass
